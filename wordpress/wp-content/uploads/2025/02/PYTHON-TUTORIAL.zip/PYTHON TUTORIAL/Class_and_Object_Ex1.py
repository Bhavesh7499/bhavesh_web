# class Calculate():
#     def add(self,a,b):
#         self.a=a
#         self.b=b
#         c=a+b
#         return c
# obj = Calculate()
# print("Total is : ",obj.add(5,6))

class Calculate():
    def __init__(self):
        print("I am Constructor")

obj = Calculate()
