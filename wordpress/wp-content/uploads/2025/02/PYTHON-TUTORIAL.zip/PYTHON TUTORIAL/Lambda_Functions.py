# One line function or anonymous function.
# def sqt(a):
#     print(a*a)

# sqt(2)

# one line expression
# sqt = lambda a : a*a
# print(sqt(6))

tot = lambda a,b : a+b
print(tot(2,5))