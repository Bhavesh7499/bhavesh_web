# Set Example: 1 (Showing unordered)
# hardware = {"Monitor","Printer","Mouse","Keyboard"}
# print(hardware)

# Set Example: 2 (Can't add duplicate Items)
# hardware = {"Monitor","Printer","Mouse","Keyboard"}
# hardware.add("Printer")
# print(hardware)

# Set Example: 3 (But we can add new Items)
# hardware = {"Monitor","Printer","Mouse","Keyboard"}
# hardware.add("CPU")
# print(hardware)

# Set Example: 4 (If you want to add multiple items)
# hardware = {"Monitor","Printer","Mouse","Keyboard"}
# hardware.update(["CPU","HDD","GPU","RAM","ROM"])
# print(hardware)