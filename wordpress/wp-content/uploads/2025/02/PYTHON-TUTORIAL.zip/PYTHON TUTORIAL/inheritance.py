class EmpPersonalInfo():
    def printDetails(self):
        print(f"Employee Name is : {self.empName} and Employee ID is : {self.empID}")
    
class Salary(EmpPersonalInfo):
    def CalculateSalary(self):
        onedaysalary=self.basicSalary/30
        workingdays=30-self.leave
        totsalary=onedaysalary*workingdays
        print("Your Salary Is : ",totsalary)

rahul = Salary()
rahul.basicSalary=30000
rahul.leave=3
rahul.empID=101
rahul.empName="Rahul"

rahul.printDetails()
rahul.CalculateSalary()

