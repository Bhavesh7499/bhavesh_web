# Example 1
# a=2
# b=5
# c=a+b
# print(c)

# Example 2
# a=int(input("Enter Ist No :"))
# b=int(input("Enter IInd No :"))
# c=a+b
# print(c)

# Example 3
# a=int(input("Enter Any No :"))
# no=a*a
# print("Result is = ",no)

# Example 4
# r=float(input("Enter Redius Value :"))
# no=3.14*r*r
# print("Result is = ",no)

#----------------------------------
# Type casting Examples

# a=int(3.14)
# print(a)

# a=str(3)
# b=2
# c=a+b
# print(c)

# ---------------------------------
# Operators Examples

# a=2
# b=3
# c=a==b
# print(c)

# a=2
# b=3
# c=a!=b
# print(c)

# a=3
# b=3
# c=a!=b
# print(c)

# a=2
# b=3
# c=a>b
# print(c)

# a=2
# b=3
# c=a<b
# print(c)

# a=2
# b=3
# b+=a
# print(b)

# a=2
# b=3
# c=5
# d=a>b and a>c
# print(d)

# a=3
# b=2
# c=1
# d=a>b and a>c
# print(d)

# a=3
# b=2
# c=5
# d=a>b or a>c
# print(d)

# a=3
# b=2
# c=not a>b
# print(c)

# a=1
# b=2
# c=not a>b
# print(c)

# a=2
# list = [1,2,3,4,5]
# if(a in list):
#     print("Yes")
# else:
#     print("No")

# a=10
# list = [1,2,3,4,5]
# if(a in list):
#     print("Yes")
# else:
#     print("No")

# x=6
# if (type(x) is int):
#     print("True")
# else:
#     print("False")

# x=6.3
# if (type(x) is int):
#     print("True")
# else:
#     print("False")

# x=6.3
# if (type(x) is not int):
#     print("True")
# else:
#     print("False")

