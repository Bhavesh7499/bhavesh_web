# name=input("Enter Your Name")
# print("Hi ! "+name)

# data="Python Course"
# x=len(data)
# print(x)

# data="Python Course"
# x=(data.lower())
# print(x)

# data="Python Course"
# x=(data.upper())
# print(x)

# data="Python Course"
# x=(data.replace("Course","Classes"))
# print(x)

# data="Python Course"
# x=(data.split())
# print(x)

# data="python course"
# x=(data.capitalize())
# print(x)

# data="python course"
# x=(data.center(50))
# print(x)

# data="python course"
# x=(data.endwith("se"))
# print(x)

# data="python course"
# x=(data.endwith("tr"))
# print(x)

# data="python course"
# x=(data.find("co"))
# print(x)

# data="python course"
# x=(data.find("o"))
# print(x)

# data="python course"
# x=(data.index("h"))
# print(x)

# data="python course"
# x=(data.isalpha())
# print(x)

# data="12345"
# x=(data.isdigit())
# print(x)

# data="Python Course"
# x=(data.isspace())
# print(x)

# data="Python Course"
# x=(data.istitle())
# print(x)

# data="I Like Apple and I also Like Mango"
# x=(data.count("Like"))
# print(x)

# list = ["sumit", "salman", "peter"]
# x="*".join(list)
# print(x)