# Dictionary Example: 1 (Creating and Printing)
# mobile = {
#     "brand": "Nokia",
#     "model": "TA-1053",
#     "year": 2018
# }
# print(mobile)

# Dictionary Example: 2 
# (Access value of the "brand" by key)
# mobile = {
#     "brand": "Nokia",
#     "model": "TA-1053",
#     "year": 2018
# }
# x=mobile["brand"]
# print(x)

# Dictionary Example: 3 
# (We can change the value of a specific item by its key name)
# mobile = {
#     "brand": "Nokia",
#     "model": "TA-1053",
#     "year": 2018
# }
# mobile["year"] = 2019
# print(mobile)

# Dictionary Example: 4 
# (If you want to get the dictionary length)
# mobile = {
#     "brand": "Nokia",
#     "model": "TA-1053",
#     "year": 2018
# }
# print(len(mobile))

# Dictionary Example: 5 
# (Adding new items)
# mobile = {
#     "brand": "Nokia",
#     "model": "TA-1053",
#     "year": 2018
# }
# mobile["color"] = "Black"
# print(mobile)

# Dictionary Example: 6 
# (Removing items)
# mobile = {
#     "brand": "Nokia",
#     "model": "TA-1053",
#     "year": 2018
# }
# mobile.pop("model")
# print(mobile)

# or
# del mobile["year"]
# print(mobile)

# Dictionary Example: 7
# (Deleting Dictionary)
# mobile = {
#     "brand": "Nokia",
#     "model": "TA-1053",
#     "year": 2018
# }
# del mobile
# print(mobile)

# Dictionary Example: 8
# (Clearing Dictionary Data)
# mobile = {
#     "brand": "Nokia",
#     "model": "TA-1053",
#     "year": 2018
# }
# mobile.clear()
# print(mobile)

# Dictionary Example: 9
# (copy of a Dictionary)
# mobile = {
#     "brand": "Nokia",
#     "model": "TA-1053",
#     "year": 2018
# }
# phone = mobile.copy()
# print(phone)