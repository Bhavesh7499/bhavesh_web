#Some Example of built in functions.

# a=2
# b=3
# c=max((a,b))
# print(c)

# a=2
# b=4
# c=sum((a,b))
# print(c)

#User defined functions.
# a=2
# def my_function():
# 	b=a*a
# 	print(b)

# my_function()

def printline():
    print("--------------------------")
def percentage(tot):
	per = tot/500*100
	return per

phy=86
che=90
math=80
hindi=55
eng=88
tot=sum((phy,che,math,hindi,eng))
result = percentage(tot)
printline()
print("Your total no. is ", tot)
printline()
print("Your percentage is ",round(result,2))
printline()





