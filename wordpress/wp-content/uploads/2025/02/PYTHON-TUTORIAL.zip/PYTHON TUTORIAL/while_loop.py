#While Loop Example
# i = 1
# while i <= 10:
#   print(i)
#   i += 1


#The break Statement
# i = 1
# while i < 7:
#   print(i)
#   if i == 4:
#     break
#   i += 1

#The continue Statement
# i = 0
# while i < 7:
#   i += 1
#   if i == 4:
#     continue
#   print(i)