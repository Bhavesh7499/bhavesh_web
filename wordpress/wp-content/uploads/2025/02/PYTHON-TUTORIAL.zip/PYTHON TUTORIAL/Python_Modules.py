# It is pre installed in python
# Example 1
# import time;
# localtime = time.asctime(time.localtime(time.time()))
# print(localtime)

# It is pre installed in python
# Example 2
# import calendar
# cal = calendar.month(2021, 4)
# print ("Calendar:")
# print (cal)


# import mymodule
# res=mymodule.cube(3)
# print(res)

# Re-naming a Module
import mymodule as sq
res = sq.sqrt(3)
print(res)
