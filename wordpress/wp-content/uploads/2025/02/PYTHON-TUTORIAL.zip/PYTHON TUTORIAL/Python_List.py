# List Exmaple: 1
# hardware = ["Monitor","Printer","Mouse","Keyboard"]
# print(hardware)

# List Exmaple: 2 (Showing Changeable)
# hardware = ["Monitor","Printer","Mouse","Keyboard"]
# hardware[1]="HDD"
# print(hardware)

# List Exmaple: 3 (Adding new items in list)
# hardware = ["Monitor","Printer","Mouse","Keyboard"]
# hardware.append=("HDD")
# hardware.append=("Printer")
# print(hardware)

# List Exmaple: 4 (Removing items in list)
# hardware = ["Monitor","Printer","Mouse","Keyboard"]
# hardware.remove=("Printer")
# print(hardware)
# print(hardware[1])

# List Exmaple: 5 (Deleting list)
# hardware = ["Monitor","Printer","Mouse","Keyboard"]
# del hardware
# print(hardware)

# List Exmaple: 6 (Clearing the list)
# hardware = ["Monitor","Printer","Mouse","Keyboard"]
# hardware.clear()
# print(hardware)