# For Loop Example No. 1
# hardware = ["Monitor", "Printer", "Mouse"]
# for x in hardware:
#   print(x)

# For Loop Example No. 2
# The range() Function
# returns a sequence of numbers, 
# starting from 0 by default, and by default 
# increments by 1.
# for x in range(7):
#   print(x) 

# For Loop Example No. 3
# for x in range(2, 7):
#   print(x)

# For Loop Example No. 4
a=int(input("Input any number for printing table : "))
for x in range(1,11):
    b=a*x
    print(a,"*",x,"=",b)

