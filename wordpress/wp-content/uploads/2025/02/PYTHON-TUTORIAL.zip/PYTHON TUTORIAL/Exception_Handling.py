# Example 1
# a=int(input("Enter Ist no = "))
# b=int(input("Enter IInd no = "))
# c=a/b
# print(c)  

# Example 2
# try:
#     a=int(input("Enter Ist no = "))
#     b=int(input("Enter IInd no = "))
#     c=a/b
#     print(c)  
# except ValueError:
#     print("Error! please input number only.")
# else:  
#     print("Thank You....") 


# Example 3
# try:
#     a=int(input("Enter Ist no = "))
#     b=int(input("Enter IInd no = "))
#     c=a/b
#     print(c)  
# except ArithmeticError:  
#     print("Error! divide by zero is not allowed")
# else:  
#     print("Thank You....")


# Example 4
# try:
#     saving=20000
#     withdrawal=30000
#     if withdrawal>saving:
#         raise Exception()
#     else: cash=saving-withdrawal
# except Exception:  
#     print("Not enough balance!")
# else:  
#     print(withdrawal,"has been debited")
#     print("The Available Balance Is :",cash)


# Example 5
# try:
#     fh = open("testfile.txt", "w")
#     fh.write("Demo")
# except IOError:
#     print("Error! can't write data in file")
# else:
#     print("Written content in the file successfully")
