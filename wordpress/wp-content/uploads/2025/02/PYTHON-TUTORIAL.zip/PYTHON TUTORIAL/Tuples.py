# Tuple Exmaple: 1 
# hardware = ("Monitor","Printer","Mouse","Keyboard")
# print(hardware)

# Tuple Exmaple: 2 (Not Changeable or immutable)
# hardware = ("Monitor","Printer","Mouse","Keyboard")
# hardware[1]="HDD"
# print(hardware)

# Tuple Exmaple: 3
# (Get the length of tuple) 
# hardware = ("Monitor","Printer","Mouse","Keyboard")
# print(len(hardware))

# Tuple Exmaple: 4 (Join Two Tuples) 
# hardware = ("Monitor","Printer","Mouse","Keyboard")
# software = ("Photoshop", "VScode", "Tally")
# x = hardware + software
# print(x)

# Tuple Exmaple: 5 (Using count() method on tuple) 
# example = ("A","B","C","A","D","E","A","F")
# x=example.count("A")
# print(x)

# Tuple Exmaple: 6 (Using index() method on tuple) 
# example = ("A","B","C","A","D","E","A","F")
# x=example.index("D")
# print(x)
